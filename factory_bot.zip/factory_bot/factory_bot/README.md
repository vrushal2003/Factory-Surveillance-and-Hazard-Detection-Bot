# Factory Surveillance Bot — Web Dashboard

A Flask-based control center for your Raspberry Pi 5 surveillance bot.

## Features
- Live MJPEG camera stream (accessible from any device on the LAN)
- Real-time sensor dashboard (Gas, Temperature, Humidity, Ultrasonic, LiDAR)
- Bot movement controls via web UI and keyboard (W A S D)
- Automatic video recording in 10-minute chunks
- Threshold-based alerts → Gmail email + GPIO siren/LED
- Sensor history charts
- Adjustable thresholds from the web UI

---

## Setup on Raspberry Pi

### 1. Install dependencies
```bash
cd factory_bot
pip install -r requirements.txt
```

On the Pi, also uncomment and install the hardware libs in requirements.txt:
```bash
pip install RPi.GPIO adafruit-circuitpython-dht adafruit-circuitpython-ads1x15 rplidar-roboticia
```

### 2. Configure Gmail alerts
Edit `alerts.py` and set:
```python
EMAIL_CONFIG = {
    'sender':   'yourbot@gmail.com',
    'password': 'your_app_password_here',   # Gmail App Password (not your login password)
    'receiver': 'owner@email.com',
}
```
> **Get a Gmail App Password:** Google Account → Security → 2-Step Verification → App Passwords

### 3. GPIO wiring

| Component        | Pi GPIO (BCM) |
|------------------|---------------|
| DHT22 data       | GPIO 4        |
| Ultrasonic TRIG  | GPIO 23       |
| Ultrasonic ECHO  | GPIO 24       |
| Siren (+)        | GPIO 17       |
| LED Red          | GPIO 27       |
| LED Green        | GPIO 22       |
| Motor A IN1      | GPIO 5        |
| Motor A IN2      | GPIO 6        |
| Motor A ENA(PWM) | GPIO 12       |
| Motor B IN3      | GPIO 13       |
| Motor B IN4      | GPIO 19       |
| Motor B ENB(PWM) | GPIO 18       |
| MQ-2 → ADS1115 A0 | I2C (SDA/SCL) |
| LiDAR            | /dev/ttyUSB0  |

### 4. Run the server
```bash
python app.py
```

The terminal will print:
```
Factory Bot server starting on http://0.0.0.0:5000
Access from LAN: http://<Pi-IP-Address>:5000
```

Find your Pi's IP:
```bash
hostname -I
```

### 5. Access from phone/PC
Open a browser and go to:
```
http://192.168.x.x:5000
```
(Replace with your Pi's actual IP)

---

## Run on boot (optional)
```bash
# Create a systemd service
sudo nano /etc/systemd/system/factorybot.service
```
Paste:
```
[Unit]
Description=Factory Bot Web Server
After=network.target

[Service]
ExecStart=/usr/bin/python3 /home/pi/factory_bot/app.py
WorkingDirectory=/home/pi/factory_bot
Restart=always
User=pi

[Install]
WantedBy=multi-user.target
```
Then:
```bash
sudo systemctl enable factorybot
sudo systemctl start factorybot
```

---

## File structure
```
factory_bot/
├── app.py           # Main Flask server
├── camera.py        # MJPEG stream + video recording
├── sensors.py       # All 5 sensors (with mock fallback)
├── alerts.py        # Threshold checks, email, GPIO siren/LED
├── bot_control.py   # L298N motor driver
├── templates/
│   └── index.html   # Full web dashboard
├── videos/          # Auto-saved mp4 recordings
├── requirements.txt
└── README.md
```
