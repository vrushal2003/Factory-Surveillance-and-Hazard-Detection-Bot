import smtplib
import time
import threading
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

try:
    import RPi.GPIO as GPIO
    REAL_HARDWARE = True
except ImportError:
    REAL_HARDWARE = False

# ── GPIO pins for physical alerts ──
SIREN_PIN = 17
LED_RED   = 27
LED_GREEN = 22

# ── Email config — fill in your details ──
EMAIL_CONFIG = {
    'sender':   'yourbot@gmail.com',        # <-- your Gmail
    'password': 'your_app_password_here',   # <-- Gmail App Password
    'receiver': 'owner@email.com',          # <-- alert recipient
    'smtp':     'smtp.gmail.com',
    'port':     587,
}

DEFAULT_THRESHOLDS = {
    'temperature_max': 60.0,   # °C
    'humidity_max':    85.0,   # %
    'gas_ppm_max':     300.0,  # ppm
    'distance_min':    15.0,   # cm (obstacle too close)
}

class AlertManager:
    def __init__(self, socketio):
        self.socketio = socketio
        self.thresholds = DEFAULT_THRESHOLDS.copy()
        self._active_alerts = set()
        self._cooldown = {}      # alert_key → last_sent timestamp
        self._cooldown_sec = 300 # 5 min between repeat emails

        if REAL_HARDWARE:
            GPIO.setmode(GPIO.BCM)
            GPIO.setwarnings(False)
            GPIO.setup(SIREN_PIN, GPIO.OUT, initial=GPIO.LOW)
            GPIO.setup(LED_RED,   GPIO.OUT, initial=GPIO.LOW)
            GPIO.setup(LED_GREEN, GPIO.OUT, initial=GPIO.HIGH)

    # ── Threshold check called every 2s ───────────────

    def check_thresholds(self, data):
        triggered = []

        checks = [
            ('temperature', data.get('temperature', 0),  self.thresholds['temperature_max'], 'high',  '°C'),
            ('humidity',    data.get('humidity', 0),     self.thresholds['humidity_max'],    'high',  '%'),
            ('gas_ppm',     data.get('gas_ppm', 0),      self.thresholds['gas_ppm_max'],     'high',  ' ppm'),
            ('distance_cm', data.get('distance_cm', 999), self.thresholds['distance_min'],   'low',   ' cm'),
        ]

        for key, value, limit, direction, unit in checks:
            breached = (direction == 'high' and value > limit) or \
                       (direction == 'low'  and value < limit)
            if breached:
                triggered.append({'sensor': key, 'value': value, 'limit': limit, 'unit': unit})
                self._active_alerts.add(key)
            else:
                self._active_alerts.discard(key)

        if triggered:
            self._fire_alerts(triggered, data)
        else:
            self._all_clear()

    def _fire_alerts(self, triggered, data):
        # Push to web UI
        self.socketio.emit('alert', {
            'triggered': triggered,
            'timestamp': data.get('timestamp', ''),
        })

        # Physical alerts
        if REAL_HARDWARE:
            GPIO.output(SIREN_PIN, GPIO.HIGH)
            GPIO.output(LED_RED,   GPIO.HIGH)
            GPIO.output(LED_GREEN, GPIO.LOW)

        # Email — throttled per sensor
        for item in triggered:
            key = item['sensor']
            now = time.time()
            last = self._cooldown.get(key, 0)
            if now - last > self._cooldown_sec:
                self._cooldown[key] = now
                threading.Thread(
                    target=self._send_email,
                    args=(item, data),
                    daemon=True
                ).start()

    def _all_clear(self):
        if REAL_HARDWARE:
            GPIO.output(SIREN_PIN, GPIO.LOW)
            GPIO.output(LED_RED,   GPIO.LOW)
            GPIO.output(LED_GREEN, GPIO.HIGH)

    # ── Email sender ──────────────────────────────────

    def _send_email(self, alert_item, all_data):
        sensor  = alert_item['sensor'].replace('_', ' ').title()
        value   = alert_item['value']
        limit   = alert_item['limit']
        unit    = alert_item['unit']

        subject = f"[FACTORY BOT ALERT] {sensor} threshold exceeded"
        body = f"""
Factory Surveillance Bot Alert
================================
Sensor   : {sensor}
Reading  : {value}{unit}
Threshold: {limit}{unit}
Time     : {all_data.get('timestamp', 'N/A')}

All sensor readings at time of alert:
  Temperature : {all_data.get('temperature')} °C
  Humidity    : {all_data.get('humidity')} %
  Gas (PPM)   : {all_data.get('gas_ppm')} ppm
  Ultrasonic  : {all_data.get('distance_cm')} cm
  LiDAR       : {all_data.get('lidar_cm')} cm

Please check the dashboard immediately.
http://<Pi-IP>:5000
        """.strip()

        msg = MIMEMultipart()
        msg['From']    = EMAIL_CONFIG['sender']
        msg['To']      = EMAIL_CONFIG['receiver']
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'plain'))

        try:
            with smtplib.SMTP(EMAIL_CONFIG['smtp'], EMAIL_CONFIG['port']) as server:
                server.starttls()
                server.login(EMAIL_CONFIG['sender'], EMAIL_CONFIG['password'])
                server.sendmail(EMAIL_CONFIG['sender'], EMAIL_CONFIG['receiver'], msg.as_string())
            print(f"[alerts] Email sent for {sensor}")
        except Exception as e:
            print(f"[alerts] Email failed: {e}")

    # ── Threshold management ───────────────────────────

    def get_thresholds(self):
        return self.thresholds.copy()

    def update_thresholds(self, new_vals):
        for k, v in new_vals.items():
            if k in self.thresholds:
                self.thresholds[k] = float(v)
        print(f"[alerts] Thresholds updated: {self.thresholds}")
