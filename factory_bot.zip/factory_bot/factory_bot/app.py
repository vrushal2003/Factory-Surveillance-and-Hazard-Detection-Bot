import os
import time
import threading
from flask import Flask, render_template, Response, jsonify, request
from flask_socketio import SocketIO, emit
from camera import Camera
from sensors import SensorManager
from alerts import AlertManager
from bot_control import BotController

app = Flask(__name__)
app.config['SECRET_KEY'] = 'factory-bot-secret-2024'
socketio = SocketIO(app, cors_allowed_origins="*")

# --- Init modules ---
camera = Camera()
sensors = SensorManager()
alerts = AlertManager(socketio)
bot = BotController()

# --- Background thread: push sensor data every 2s ---
def sensor_broadcast_loop():
    while True:
        data = sensors.read_all()
        alerts.check_thresholds(data)
        socketio.emit('sensor_data', data)
        time.sleep(2)

sensor_thread = threading.Thread(target=sensor_broadcast_loop, daemon=True)
sensor_thread.start()

# ── Routes ──────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    """MJPEG stream endpoint — just point an <img> tag here."""
    return Response(
        camera.generate_frames(),
        mimetype='multipart/x-mixed-replace; boundary=frame'
    )

@app.route('/api/sensors')
def api_sensors():
    return jsonify(sensors.read_all())

@app.route('/api/videos')
def api_videos():
    video_dir = os.path.join(os.path.dirname(__file__), 'videos')
    files = []
    for f in sorted(os.listdir(video_dir), reverse=True):
        if f.endswith('.mp4'):
            path = os.path.join(video_dir, f)
            files.append({
                'name': f,
                'size_mb': round(os.path.getsize(path) / (1024 * 1024), 2),
                'modified': time.strftime('%Y-%m-%d %H:%M', time.localtime(os.path.getmtime(path)))
            })
    return jsonify(files)

@app.route('/videos/<filename>')
def serve_video(filename):
    from flask import send_from_directory
    return send_from_directory('videos', filename)

@app.route('/api/control', methods=['POST'])
def control():
    data = request.get_json()
    cmd = data.get('command')
    speed = data.get('speed', 50)
    result = bot.execute(cmd, speed)
    return jsonify({'status': 'ok', 'command': cmd, 'result': result})

@app.route('/api/alerts/thresholds', methods=['GET', 'POST'])
def alert_thresholds():
    if request.method == 'POST':
        alerts.update_thresholds(request.get_json())
        return jsonify({'status': 'updated'})
    return jsonify(alerts.get_thresholds())

# ── SocketIO events ──────────────────────────────────

@socketio.on('connect')
def on_connect():
    emit('sensor_data', sensors.read_all())

@socketio.on('control')
def on_control(data):
    cmd = data.get('command')
    speed = data.get('speed', 50)
    bot.execute(cmd, speed)

if __name__ == '__main__':
    print("Factory Bot server starting on http://0.0.0.0:5000")
    print("Access from LAN: http://<Pi-IP-Address>:5000")
    socketio.run(app, host='0.0.0.0', port=5000, debug=False)
