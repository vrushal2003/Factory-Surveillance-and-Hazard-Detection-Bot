import time

try:
    import RPi.GPIO as GPIO
    REAL_HARDWARE = True
except ImportError:
    REAL_HARDWARE = False

# ── L298N Motor Driver Pins (BCM) ──
# Motor A (Left)
IN1 = 5
IN2 = 6
ENA = 12   # PWM
# Motor B (Right)
IN3 = 13
IN4 = 19
ENB = 18   # PWM

class BotController:
    def __init__(self):
        self.speed = 50   # 0-100%
        self.pwm_a = None
        self.pwm_b = None

        if REAL_HARDWARE:
            self._init_gpio()

    def _init_gpio(self):
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)
        for pin in [IN1, IN2, IN3, IN4, ENA, ENB]:
            GPIO.setup(pin, GPIO.OUT)

        self.pwm_a = GPIO.PWM(ENA, 1000)
        self.pwm_b = GPIO.PWM(ENB, 1000)
        self.pwm_a.start(0)
        self.pwm_b.start(0)

    def _set_speed(self, speed):
        self.speed = max(0, min(100, speed))
        if REAL_HARDWARE and self.pwm_a:
            self.pwm_a.ChangeDutyCycle(self.speed)
            self.pwm_b.ChangeDutyCycle(self.speed)

    def execute(self, command, speed=50):
        self._set_speed(speed)
        actions = {
            'forward':   self._forward,
            'backward':  self._backward,
            'left':      self._turn_left,
            'right':     self._turn_right,
            'stop':      self._stop,
        }
        fn = actions.get(command)
        if fn:
            fn()
            return f"Executed: {command} @ {speed}%"
        return f"Unknown command: {command}"

    def _forward(self):
        if REAL_HARDWARE:
            GPIO.output(IN1, GPIO.HIGH); GPIO.output(IN2, GPIO.LOW)
            GPIO.output(IN3, GPIO.HIGH); GPIO.output(IN4, GPIO.LOW)
        print(f"[bot] FORWARD @ {self.speed}%")

    def _backward(self):
        if REAL_HARDWARE:
            GPIO.output(IN1, GPIO.LOW);  GPIO.output(IN2, GPIO.HIGH)
            GPIO.output(IN3, GPIO.LOW);  GPIO.output(IN4, GPIO.HIGH)
        print(f"[bot] BACKWARD @ {self.speed}%")

    def _turn_left(self):
        if REAL_HARDWARE:
            GPIO.output(IN1, GPIO.LOW);  GPIO.output(IN2, GPIO.HIGH)
            GPIO.output(IN3, GPIO.HIGH); GPIO.output(IN4, GPIO.LOW)
        print(f"[bot] LEFT @ {self.speed}%")

    def _turn_right(self):
        if REAL_HARDWARE:
            GPIO.output(IN1, GPIO.HIGH); GPIO.output(IN2, GPIO.LOW)
            GPIO.output(IN3, GPIO.LOW);  GPIO.output(IN4, GPIO.HIGH)
        print(f"[bot] RIGHT @ {self.speed}%")

    def _stop(self):
        if REAL_HARDWARE:
            for pin in [IN1, IN2, IN3, IN4]:
                GPIO.output(pin, GPIO.LOW)
        print("[bot] STOP")
