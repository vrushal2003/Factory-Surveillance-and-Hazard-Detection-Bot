import cv2
import time
import os
import threading
from datetime import datetime

class Camera:
    def __init__(self, camera_index=0, record=True):
        self.camera_index = camera_index
        self.record = record
        self.cap = None
        self.lock = threading.Lock()
        self.current_frame = None
        self.recording = False
        self.video_writer = None
        self.video_dir = os.path.join(os.path.dirname(__file__), 'videos')
        os.makedirs(self.video_dir, exist_ok=True)

        # Start capture thread
        self._capture_thread = threading.Thread(target=self._capture_loop, daemon=True)
        self._capture_thread.start()

        # Auto-record in 10-minute chunks
        if self.record:
            self._record_thread = threading.Thread(target=self._record_loop, daemon=True)
            self._record_thread.start()

    def _open_camera(self):
        cap = cv2.VideoCapture(self.camera_index)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        cap.set(cv2.CAP_PROP_FPS, 20)
        return cap

    def _capture_loop(self):
        self.cap = self._open_camera()
        while True:
            if self.cap and self.cap.isOpened():
                ret, frame = self.cap.read()
                if ret:
                    # Overlay: timestamp
                    ts = datetime.now().strftime('%Y-%m-%d  %H:%M:%S')
                    cv2.putText(frame, ts, (10, 25),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 100), 1)
                    cv2.putText(frame, 'FACTORY BOT CAM', (10, 460),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 100), 1)
                    with self.lock:
                        self.current_frame = frame.copy()
                    if self.video_writer:
                        self.video_writer.write(frame)
            time.sleep(0.04)  # ~25 fps

    def _record_loop(self):
        """Save 10-minute video chunks continuously."""
        chunk_duration = 10 * 60  # seconds
        while True:
            filename = datetime.now().strftime('rec_%Y%m%d_%H%M%S.mp4')
            filepath = os.path.join(self.video_dir, filename)
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            self.video_writer = cv2.VideoWriter(filepath, fourcc, 20.0, (640, 480))
            time.sleep(chunk_duration)
            old_writer = self.video_writer
            self.video_writer = None
            old_writer.release()
            # Keep only last 50 recordings (~8 hrs)
            self._cleanup_old_videos(keep=50)

    def _cleanup_old_videos(self, keep=50):
        files = sorted(
            [f for f in os.listdir(self.video_dir) if f.endswith('.mp4')],
            reverse=True
        )
        for old in files[keep:]:
            os.remove(os.path.join(self.video_dir, old))

    def generate_frames(self):
        """Yield MJPEG frames for the /video_feed route."""
        while True:
            with self.lock:
                frame = self.current_frame
            if frame is None:
                time.sleep(0.1)
                continue
            ret, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 70])
            if ret:
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' +
                       buffer.tobytes() + b'\r\n')
            time.sleep(0.05)

    def get_snapshot(self):
        with self.lock:
            return self.current_frame.copy() if self.current_frame is not None else None
