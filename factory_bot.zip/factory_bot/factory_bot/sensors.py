import time
import random

# ── Import real sensor libs (comment out if testing on non-Pi) ──
try:
    import board
    import adafruit_dht
    import adafruit_ads1x15.ads1115 as ADS
    from adafruit_ads1x15.analog_in import AnalogIn
    import busio
    import RPi.GPIO as GPIO
    REAL_HARDWARE = True
except ImportError:
    REAL_HARDWARE = False
    print("[sensors] Running in MOCK mode — no GPIO/sensor libs found.")

# ── GPIO pin config (BCM numbering) ──
TRIG_PIN   = 23   # Ultrasonic TRIG
ECHO_PIN   = 24   # Ultrasonic ECHO
DHT_PIN    = 4    # DHT22 data pin

class SensorManager:
    def __init__(self):
        self._last_values = {
            'temperature': 25.0,
            'humidity': 50.0,
            'gas_ppm': 0.0,
            'distance_cm': 100.0,
            'lidar_cm': 100.0,
        }
        if REAL_HARDWARE:
            self._init_hardware()

    def _init_hardware(self):
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)

        # Ultrasonic
        GPIO.setup(TRIG_PIN, GPIO.OUT)
        GPIO.setup(ECHO_PIN, GPIO.IN)

        # DHT22
        self.dht = adafruit_dht.DHT22(getattr(board, f'D{DHT_PIN}'))

        # MQ-2 gas sensor via ADS1115 ADC (I2C)
        i2c = busio.I2C(board.SCL, board.SDA)
        ads = ADS.ADS1115(i2c)
        self.gas_channel = AnalogIn(ads, ADS.P0)

        # LiDAR (RPLIDAR A1 via serial — reads distance over USB serial)
        try:
            from rplidar import RPLidar
            self.lidar = RPLidar('/dev/ttyUSB0')
        except Exception:
            self.lidar = None
            print("[sensors] LiDAR not connected.")

    # ── Individual sensor readers ──────────────────────

    def _read_dht(self):
        try:
            return self.dht.temperature, self.dht.humidity
        except Exception:
            return self._last_values['temperature'], self._last_values['humidity']

    def _read_ultrasonic(self):
        try:
            GPIO.output(TRIG_PIN, False)
            time.sleep(0.01)
            GPIO.output(TRIG_PIN, True)
            time.sleep(0.00001)
            GPIO.output(TRIG_PIN, False)
            timeout = time.time() + 0.04
            while GPIO.input(ECHO_PIN) == 0:
                if time.time() > timeout: return self._last_values['distance_cm']
            pulse_start = time.time()
            while GPIO.input(ECHO_PIN) == 1:
                if time.time() > timeout: return self._last_values['distance_cm']
            pulse_end = time.time()
            distance = round((pulse_end - pulse_start) * 17150, 2)
            return min(max(distance, 2), 400)
        except Exception:
            return self._last_values['distance_cm']

    def _read_gas(self):
        try:
            voltage = self.gas_channel.voltage
            # Approximate PPM from voltage (calibrate for your MQ-2)
            ppm = round((voltage / 3.3) * 1000, 1)
            return ppm
        except Exception:
            return self._last_values['gas_ppm']

    def _read_lidar(self):
        try:
            if not self.lidar:
                return self._last_values['lidar_cm']
            for scan in self.lidar.iter_scans():
                distances = [meas[2] for meas in scan if meas[2] > 0]
                if distances:
                    return round(min(distances) / 10, 1)  # mm → cm
        except Exception:
            return self._last_values['lidar_cm']

    # ── Mock reader for dev/testing ────────────────────

    def _mock_read(self):
        t = self._last_values['temperature'] + random.uniform(-0.3, 0.3)
        h = self._last_values['humidity'] + random.uniform(-0.5, 0.5)
        g = max(0, self._last_values['gas_ppm'] + random.uniform(-5, 5))
        d = max(5, self._last_values['distance_cm'] + random.uniform(-2, 2))
        l = max(5, self._last_values['lidar_cm'] + random.uniform(-3, 3))
        return {
            'temperature': round(t, 1),
            'humidity': round(min(max(h, 20), 95), 1),
            'gas_ppm': round(g, 1),
            'distance_cm': round(d, 1),
            'lidar_cm': round(l, 1),
            'timestamp': time.strftime('%H:%M:%S'),
            'mock': True
        }

    # ── Main public method ─────────────────────────────

    def read_all(self):
        if not REAL_HARDWARE:
            data = self._mock_read()
            self._last_values.update({k: v for k, v in data.items() if k in self._last_values})
            return data

        temp, hum   = self._read_dht()
        distance    = self._read_ultrasonic()
        gas         = self._read_gas()
        lidar       = self._read_lidar()

        data = {
            'temperature': round(temp, 1),
            'humidity':    round(hum, 1),
            'gas_ppm':     round(gas, 1),
            'distance_cm': round(distance, 1),
            'lidar_cm':    round(lidar, 1),
            'timestamp':   time.strftime('%H:%M:%S'),
            'mock':        False
        }
        self._last_values.update({k: v for k, v in data.items() if k in self._last_values})
        return data
